<?php

    $family = array("Rob", "Kirsten", "Tommy", "Ralphie");

    $i = 0;

    while ($i < sizeof($family)) {
        
        echo $family[$i]."<br>";
        
        $i++;
        
    }




    $i = 1;

    while ($i <= 10) {
        
        $j = $i * 5;
        
        echo $j."<br>";
        
        $i++;
        
    }

?>